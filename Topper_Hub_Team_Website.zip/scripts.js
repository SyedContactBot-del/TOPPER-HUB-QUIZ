
document.addEventListener("DOMContentLoaded", function() {
  const leaderboard = [
    { name: "Alice", score: 95 },
    { name: "Bob", score: 90 },
    { name: "Charlie", score: 85 },
  ];

  const leaderboardList = document.getElementById("leaderboard-list");
  leaderboard.forEach(player => {
    const playerDiv = document.createElement("div");
    playerDiv.innerHTML = `<strong>${player.name}</strong> - ${player.score} points`;
    leaderboardList.appendChild(playerDiv);
  });
});
